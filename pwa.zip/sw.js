/* 定期テスト対策 PWA：アプリ本体だけを保存（オフラインでも開ける）。Firebase などの通信は保存しない */
const VER = 'kj-pwa-1';
const SHELL = ['./', 'index.html', 'manifest.webmanifest', 'icon-192.png', 'icon-512.png', 'apple-touch-icon.png'];
self.addEventListener('install', e => { e.waitUntil(caches.open(VER).then(c => c.addAll(SHELL)).then(() => self.skipWaiting())); });
self.addEventListener('activate', e => { e.waitUntil(caches.keys().then(ks => Promise.all(ks.filter(k => k !== VER).map(k => caches.delete(k)))).then(() => self.clients.claim())); });
self.addEventListener('fetch', e => {
  const r = e.request, u = new URL(r.url);
  if(r.method !== 'GET' || u.origin !== location.origin) return;       /* 他サイト（Firebase・フォント等）は触らない */
  /* 新しい版を先に取りに行き、つながらないときだけ保存分を出す（更新がすぐ反映される） */
  e.respondWith(fetch(r).then(res => { if(res.ok){ const c = res.clone(); caches.open(VER).then(x => x.put(r, c)); } return res; }).catch(() => caches.match(r).then(m => m || caches.match('index.html'))));
});
